import eu.bitwalker.useragentutils.UserAgent;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.PrimitiveObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.io.Text;

import java.util.ArrayList;

public class UDF_Parser extends GenericUDTF {
    private Text[] table = null;
    private PrimitiveObjectInspector ua = null;

    public StructObjectInspector initialize(ObjectInspector[] arg)
    {
        ArrayList<String> fieldNames = new ArrayList<>();
        ArrayList<ObjectInspector> fields = new ArrayList<>();

        ua = (PrimitiveObjectInspector) arg[0];

        fieldNames.add("device");
        fields.add(PrimitiveObjectInspectorFactory.getPrimitiveJavaObjectInspector( PrimitiveObjectInspector.PrimitiveCategory.STRING));

        fieldNames.add("OS");
        fields.add(PrimitiveObjectInspectorFactory.getPrimitiveJavaObjectInspector( PrimitiveObjectInspector.PrimitiveCategory.STRING));

        fieldNames.add("Browser");
        fields.add(PrimitiveObjectInspectorFactory.getPrimitiveJavaObjectInspector( PrimitiveObjectInspector.PrimitiveCategory.STRING));

        fieldNames.add("UA");
        fields.add(PrimitiveObjectInspectorFactory.getPrimitiveJavaObjectInspector( PrimitiveObjectInspector.PrimitiveCategory.STRING));


        table = new Text[4];
        return ObjectInspectorFactory.getStandardStructObjectInspector(
                fieldNames, fields);
    }

    public void process(Object[] record) throws HiveException
    {
        String agent = ua.getPrimitiveJavaObject(record[0]).toString();


        table[0] = new Text(UserAgent.parseUserAgentString(agent).getOperatingSystem().getDeviceType().getName());
        table[1] = new Text(UserAgent.parseUserAgentString(agent).getOperatingSystem().getGroup().name());
        table[2] = new Text(UserAgent.parseUserAgentString(agent).getBrowser().getGroup().getName());
        table[3] = new Text(UserAgent.parseUserAgentString(agent).getBrowser().getGroup().getBrowserType().getName());

        this.forward(table);

    }

    public void close()
    {

    }
}